package jisuanqi;

public class test11 {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Login l = new Login();
    }

}
